<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/src/PHPMailer.php';
require __DIR__ . '/src/SMTP.php';
require __DIR__ . '/src/Exception.php';

function sendEmail($to, $subject, $body, $fromName, $fromEmail) {
    $mail = new PHPMailer(true);

    try {
        // تنظیمات SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // اگر از Gmail استفاده می‌کنی
        $mail->SMTPAuth = true;
        $mail->Username = 'nimax13x@gmail.com';       // 🔒 جایگزین کن با ایمیل خودت
        $mail->Password = 'mxlu tzyr jdue wgha';         // 🔒 رمز اپلیکیشن Gmail (نه رمز اصلی!)
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // فرستنده و گیرنده
        $mail->setFrom($fromEmail, $fromName);
        $mail->addAddress($to);     // مدیر سایت

        // محتوا
        $mail->isHTML(false);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        return true;

    } catch (Exception $e) {
        return false;
    }
}