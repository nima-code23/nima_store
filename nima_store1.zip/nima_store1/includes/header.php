<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;

$user = $_SESSION['user'] ?? null;
$username = $user['username'] ?? null;
$role = $user['role'] ?? null;
?>

<?php if ($username): ?>
    <div class="bg-success text-white text-center py-2 fw-bold" style="font-size: 1.1rem;">
        👋 سلام <?= htmlspecialchars($username) ?>! به فروشگاه NIMA STORE خوش آمدی 💚
    </div>
<?php endif; ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/nima_store1/products.php">👟 Nima Store</a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu" aria-controls="navMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">

                <?php if ($username): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/nima_store1/products.php">🛍 محصولات</a>
                    </li>

                    <?php if ($role === 'seller'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/nima_store1/upload_product.php">➕ افزودن محصول</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                            <a class="nav-link" href="/nima_store1/contact.php">📬 تماس با ما</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="/nima_store1/logout.php">🚪 خروج</a>
                    </li>

                    <li class="nav-item position-relative">
                        <a class="nav-link" href="/nima_store1/cart.php">
                            🛒 سبد خرید
                            <?php if ($cart_count > 0): ?>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-success">
                                    <?= $cart_count ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/nima_store1/register.php">📝 ثبت‌نام</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/nima_store1/login.php">🔐 ورود</a>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</nav>