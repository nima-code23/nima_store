<?php
header('Content-Type: text/html; charset=utf-8');

$api_key = 'FreeM3v20RXuaHbjpQnde8kGerM44qMH';
$url = "https://BrsApi.ir/Api/Market/Gold_Currency_Pro.php?key={$api_key}&section=currency";

$response = @file_get_contents($url);
if (!$response) {
    echo 'نرخ دلار در دسترس نیست.';
    exit;
}

$data = json_decode($response, true);

if (!empty($data['currency'])) {
    foreach ($data['currency'] as $item) {
        if (!empty($item['symbol']) && $item['symbol'] === 'USD') {
            $rate = intval($item['price']);
            echo number_format($rate) . ' ریال';
            exit;
        }
    }
    echo 'قیمت دلار در پاسخ API نبود.';
} else {
    echo 'داده ارز دریافت نشد.';
}
?>