<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'seller') {
    header("Location: login.php");
    exit;
}

include 'includes/db.php';
include 'includes/header.php'; 

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $price = $_POST['price'];
    $description = htmlspecialchars($_POST['description']);
    $category = $_POST['category'] ?? 'سایر';

    $image = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];
    $target = "uploads/" . basename($image);

    if (move_uploaded_file($tmp, $target)) {
        $stmt = $conn->prepare("INSERT INTO products (name, price_dollar, description, image, category) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sdsss", $name, $price, $description, $image, $category);

        if ($stmt->execute()) {
            $message = "✅ محصول با موفقیت اضافه شد!";
        } else {
            $message = "❌ خطا در ثبت محصول: " . $conn->error;
        }

        $stmt->close();
    } else {
        $message = "❌ آپلود تصویر با خطا مواجه شد.";
    }
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>افزودن محصول | Nima Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow p-4">
                <h2 class="text-center mb-4">➕ افزودن محصول جدید</h2>

                <?php if ($message): ?>
                    <div class="alert alert-info"><?= $message ?></div>
                <?php endif; ?>

                <form method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">نام محصول:</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">قیمت (دلار):</label>
                        <input type="number" name="price" class="form-control" required step="0.01">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">توضیحات:</label>
                        <textarea name="description" class="form-control" rows="4" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">دسته‌بندی:</label>
                        <select name="category" class="form-select" required>
                            <option value="نایکی">نایکی</option>
                            <option value="آدیداس">آدیداس</option>
                            <option value="پوما">پوما</option>
                            <option value="ریباک">ریباک</option>
                            <option value="سایر">سایر</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">عکس محصول:</label>
                        <input type="file" name="image" class="form-control" accept="image/*" required>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">📦 ثبت محصول</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>