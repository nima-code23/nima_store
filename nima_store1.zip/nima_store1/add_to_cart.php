<?php
session_start();

// بررسی ورود کاربر
if (!isset($_SESSION['user'])) {
    http_response_code(403);
    echo "کاربر وارد نشده است.";
    exit;
}

// مقداردهی اولیه به سبد خرید
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['product_id'] ?? null;
    $name = $_POST['name'] ?? null;
    $price = floatval($_POST['price'] ?? 0);

    if (!$id || !$name || $price <= 0) {
        http_response_code(400);
        echo "داده‌های نامعتبر.";
        exit;
    }

    // اگر محصول وجود داشت، تعداد را زیاد کن
    if (isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id]['quantity'] += 1;
    } else {
        $_SESSION['cart'][$id] = [
            'id' => $id,
            'name' => $name,
            'price' => $price,
            'quantity' => 1
        ];
    }

    echo "success";
    exit;
}
?>