<?php
$apiKey = '562d862d54f3dc9638a1b85bdb'; // کلید خودت
$response = @file_get_contents("https://v6.exchangerate-api.com/v6/$apiKey/latest/USD");

if ($response === false) {
    echo "⛔ خطا در اتصال به API";
} else {
    $data = json_decode($response, true);
    echo "<pre>";
    print_r($data);
    echo "</pre>";
}