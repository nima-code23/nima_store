<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>Nima Store - فروشگاه کفش</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
        <a class="navbar-brand" href="index.php">Nima Store</a>
        <div class="collapse navbar-collapse">
          <ul class="navbar-nav ms-auto">
            <?php if (isset($_SESSION['username'])): ?>
                <li class="nav-item"><a class="nav-link" href="upload_product.php">افزودن محصول</a></li>
                <li class="nav-item"><a class="nav-link" href="cart.php">سبد خرید</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">خروج</a></li>
            <?php else: ?>
                <li class="nav-item"><a class="nav-link" href="register.php">ثبت‌نام</a></li>
                <li class="nav-item"><a class="nav-link" href="login.php">ورود</a></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container mt-5">
        <h1 class="text-center mb-4">خوش آمدید به فروشگاه کفش Nima Store 👟</h1>
        <div class="text-center">
            <a href="products.php" class="btn btn-primary">مشاهده محصولات</a>
        </div>
    </div>
</body>
</html>