<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'seller') {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    die("شناسه محصول مشخص نیست.");
}

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$product) {
    die("محصول پیدا نشد.");
}

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $price = floatval($_POST['price']);
    $description = htmlspecialchars($_POST['description']);
    $category = htmlspecialchars($_POST['category']);

    // اگر تصویر جدید آپلود شده بود:
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];
        $target = "uploads/" . basename($image);

        if (move_uploaded_file($tmp, $target)) {
            $stmt = $conn->prepare("UPDATE products SET name=?, price_dollar=?, description=?, category=?, image=? WHERE id=?");
            $stmt->bind_param("sdsssi", $name, $price, $description, $category, $image, $id);
        } else {
            $message = "آپلود تصویر با خطا مواجه شد.";
        }
    } else {
        // اگر تصویر تغییر نکرده:
        $stmt = $conn->prepare("UPDATE products SET name=?, price_dollar=?, description=?, category=? WHERE id=?");
        $stmt->bind_param("sdssi", $name, $price, $description, $category, $id);
    }

    if ($stmt->execute()) {
        $message = "✅ محصول با موفقیت ویرایش شد!";
    } else {
        $message = "❌ خطا در ویرایش: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>ویرایش محصول</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="card shadow-sm p-4">
        <h3 class="mb-4 text-center">✏️ ویرایش محصول</h3>

        <?php if ($message): ?>
            <div class="alert alert-info"><?= $message ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">نام محصول</label>
                <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">قیمت (دلار)</label>
                <input type="number" step="0.01" name="price" value="<?= $product['price_dollar'] ?>" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">توضیحات</label>
                <textarea name="description" class="form-control" required><?= htmlspecialchars($product['description']) ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">دسته‌بندی</label>
                <select name="category" class="form-select">
                    <?php
                    $categories = ['PUMA', 'NIKE', 'BALENCIAGA', 'ADIDAS'];
                    foreach ($categories as $cat):
                        $selected = $product['category'] === $cat ? 'selected' : '';
                        echo "<option value=\"$cat\" $selected>$cat</option>";
                    endforeach;
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">تغییر عکس (در صورت نیاز)</label>
                <input type="file" name="image" class="form-control" accept="image/*">
            </div>

            <button type="submit" class="btn btn-warning w-100">ثبت تغییرات</button>
        </form>
    </div>
</div>
</body>
</html>