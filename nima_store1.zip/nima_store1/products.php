<?php
session_start();
include 'includes/db.php';
include 'includes/header.php'; 

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['user']['role'] ?? null;

// گرفتن نرخ دلار با cURL
$rate = 0;
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => "https://open.er-api.com/v6/latest/USD",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 10,
]);
$response = curl_exec($curl);
curl_close($curl);

if ($response) {
    $data = json_decode($response, true);
    if (isset($data['rates']['IRR'])) {
        $rate = intval($data['rates']['IRR']);
    }
}

// فیلتر بر اساس دسته‌بندی
$filter = $_GET['category'] ?? null;
if ($filter) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE category = ?");
    $stmt->bind_param("s", $filter);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM products");
}
?>
<!DOCTYPE html>
<html lang="fa">
<head>
<meta charset="UTF-8">
<title>محصولات | Nima Store</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="/nima_store1/assets/style.css">
</head>
<body>

<?php if ($rate > 0): ?>
    <div class="dollar-box p-2 bg-warning text-center mb-3">
        💵 نرخ دلار: <strong><?= number_format($rate) ?> ریال</strong>
    </div>
<?php endif; ?>

<div class="text-center mb-4">
    <a href="products.php" class="btn btn-outline-secondary me-2">🏷 همه</a>
    <a href="products.php?category=NIKE" class="btn btn-outline-primary me-2">NIKE</a>
    <a href="products.php?category=ADIDAS" class="btn btn-outline-primary me-2">ADIDAS</a>
    <a href="products.php?category=PUMA" class="btn btn-outline-primary me-2">PUMA</a>
    <a href="products.php?category=BALENCIAGA" class="btn btn-outline-primary me-2">BALENCIAGA</a>
</div>

<div class="container mt-3">
    <h2 class="text-center mb-4">محصولات کفش</h2>
    <div class="row">

    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="col-md-4 mb-4">
            <div class="card product-card h-100 shadow-sm">
                <img src="uploads/<?= htmlspecialchars($row['image']) ?>" class="card-img-top" style="height: 250px; object-fit: cover; border-radius: 15px 15px 0 0;" alt="<?= htmlspecialchars($row['name']) ?>">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
                    
                    <p class="card-text flex-grow-1"><?= nl2br(htmlspecialchars($row['description'])) ?></p>

                    <p class="card-text fw-bold text-success">$<?= floatval($row['price_dollar']) ?></p>

                    <?php if ($rate > 0): ?>
                        <p class="card-text text-muted">
                            معادل ریالی: <?= number_format(floatval($row['price_dollar']) * $rate) ?> ریال
                        </p>
                    <?php endif; ?>

                    <a href="/nima_store1/product.php?id=<?= $row['id'] ?>" class="btn btn-outline-primary mb-2">مشاهده محصول</a>

                    <form method="post" action="/nima_store1/add_to_cart.php" class="add-to-cart-form mt-auto" data-product-name="<?= htmlspecialchars($row['name']) ?>">
                        <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
                        <input type="hidden" name="name" value="<?= htmlspecialchars($row['name']) ?>">
                        <input type="hidden" name="price" value="<?= floatval($row['price_dollar']) ?>">
                        <button type="submit" class="btn btn-success w-100">افزودن به سبد خرید</button>
                    </form>

                    <?php if ($role === 'seller'): ?>
                        <form method="post" action="delete_product.php" onsubmit="return confirm('آیا مطمئن هستید؟')">
                            <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-danger w-100 mt-2">🗑 حذف محصول</button>
                        </form>
                        <a href="edit_product.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning w-100 mt-2">✏️ ویرایش محصول</a>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    <?php endwhile; ?>

    </div>
</div>

<script>
document.querySelectorAll('.add-to-cart-form').forEach(form => {
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(this);

        fetch(this.action, {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            showToast(`✅ محصول "${this.dataset.productName}" به سبد خرید اضافه شد.`);
            updateCartCount();
        })
        .catch(err => {
            showToast('❌ خطا در افزودن به سبد خرید.');
        });
    });
});

function showToast(message) {
    let toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => toast.classList.add('show'), 100);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function updateCartCount() {
    fetch('/nima_store1/cart_count.php')
        .then(res => res.json())
        .then(data => {
            const badge = document.querySelector('.navbar .badge.bg-success');
            if (badge) {
                badge.textContent = data.count;
            }
        });
}
</script>

<style>
.toast-message {
    position: fixed;
    bottom: 30px;
    right: 30px;
    background: #198754;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    opacity: 0;
    transform: translateY(20px);
    transition: opacity 0.3s ease, transform 0.3s ease;
    font-weight: bold;
    z-index: 10000;
    pointer-events: none;
}
.toast-message.show {
    opacity: 1;
    transform: translateY(0);
}
.dollar-box {
    font-weight: bold;
    font-size: 1.2rem;
    margin-bottom: 1rem;
    text-align: center;
}
</style>

</body>
</html>