<?php
session_start();
session_unset(); // حذف تمام متغیرهای سشن
session_destroy(); // پایان جلسه کاربری

header("Location: login.php");
exit;