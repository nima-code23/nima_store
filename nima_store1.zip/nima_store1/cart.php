<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// نرخ دلار از API
$rate = 0;
$response = @file_get_contents("https://open.er-api.com/v6/latest/USD");
if ($response) {
    $data = json_decode($response, true);
    if (isset($data['rates']['IRR'])) {
        $rate = intval($data['rates']['IRR']);
    }
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>🛒 سبد خرید شما | Nima Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container { max-width: 900px; }
    </style>
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center mb-4">🛒 سبد خرید شما</h2>

    <?php
    $total_dollar = 0;
    $total_rial = 0;

    if (!empty($_SESSION['cart'])):
    ?>
    <table class="table table-striped text-center align-middle">
        <thead class="table-dark">
            <tr>
                <th>نام محصول</th>
                <th>قیمت واحد (دلار)</th>
                <th>تعداد</th>
                <th>قیمت کل (ریال)</th>
                <th>عملیات</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($_SESSION['cart'] as $item):
                $price_dollar = floatval($item['price']);
                $quantity = intval($item['quantity']);
                $price_rial = $rate > 0 ? $price_dollar * $rate * $quantity : 0;

                $total_dollar += $price_dollar * $quantity;
                $total_rial += $price_rial;
            ?>
            <tr>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td>$<?= number_format($price_dollar, 2) ?></td>
                <td>
                    <form method="post" action="update_quantity.php" class="d-inline">
                        <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
                        <input type="hidden" name="action" value="decrease">
                        <button type="submit" class="btn btn-sm btn-outline-danger">➖</button>
                    </form>

                    <span class="mx-2 fw-bold"><?= $quantity ?></span>

                    <form method="post" action="update_quantity.php" class="d-inline">
                        <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
                        <input type="hidden" name="action" value="increase">
                        <button type="submit" class="btn btn-sm btn-outline-success">➕</button>
                    </form>
                </td>
                <td><?= number_format($price_rial) ?> ریال</td>
                <td>
                    <form method="post" action="remove_from_cart.php" onsubmit="return confirm('آیا مطمئنی؟');">
                        <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-danger">🗑 حذف</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="text-center fw-bold fs-5 mt-3">
        💵 مجموع کل: <span class="text-primary">$<?= number_format($total_dollar, 2) ?></span> / 
        <span class="text-success"><?= number_format($total_rial) ?> ریال</span>
    </div>

    <?php else: ?>
        <div class="alert alert-info text-center">سبد خرید شما خالی است.</div>
    <?php endif; ?>
</div>

</body>
</html>