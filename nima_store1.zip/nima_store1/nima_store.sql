-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2025 at 11:20 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nima_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(1, 'نیما', 'nimaabedi9@gmail.com', 'این یک تست است', 'این متن صرفا جهت تست سایت است', '2025-07-14 21:22:17'),
(2, 'نیما', 'nimaabedi9@gmail.com', 'این یک تست است', 'این متن صرفا جهت تست سایت است', '2025-07-14 21:51:32');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `price_dollar` decimal(10,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT 'سایر'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price_dollar`, `description`, `image`, `category`) VALUES
(1, 'NIKE', '120.00', 'Nike Shoes Branded Men Women Sneakers Air Sport Basketball Running Nike Factory', 'airmax.jpg', 'NIKE'),
(4, 'NIKE', '270.00', 'Nike Dunk Low Women\'s Shoes', 'nike1.jfif', 'NIKE'),
(5, 'NIKE', '245.00', 'Nike Dunk High By You Custom Men\'s Shoes', 'nike2.avif', 'NIKE'),
(6, 'Balenciaga shoes', '2400.00', 'Men\'s Bouncer Sneaker in Black | Balenciaga US', 'balenciaga1.jfif', 'BALENCIAGA'),
(7, 'Balenciaga shoes', '2700.00', 'Balenciaga 3XL Sneakers in yellow | RADPRESENT', 'balenciagashoe.jpeg', 'BALENCIAGA'),
(8, 'Balenciaga shoes', '1170.00', 'Balenciaga X-Pander Black Marathon Running Shoes', '653870W2RA21000.png', 'BALENCIAGA'),
(9, 'PUMA', '786.00', 'Amplifier Men\'s Sneakers | PUMA', 'images.jfif', 'PUMA'),
(10, 'PUMA', '483.00', 'Puma RS Black / Orange / Blue - Fast delivery | Spartoo Europe ! ', '11111).jfif', 'PUMA'),
(12, 'ADIDAS', '864.00', 'Adidas Shoes, Sneakers &amp;amp; Accessories | Shoe Carnival', '33333.jpg', 'ADIDAS'),
(13, 'ADIDAS', '1750.00', 'Shop Premium Adidas Forum Mid Sneakers ', '55ed.jpg', 'ADIDAS'),
(14, 'ADIDAS', '1240.00', ' ADIDAS MEN EQ21 RUN SHOES', '6632436.jpg', 'ADIDAS'),
(15, 'PUMA', '284.00', 'Puma Shoes Delphin Blue', '2222(1).jfif', 'PUMA');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('buyer','seller') DEFAULT 'buyer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`) VALUES
(1, 'nima', 'nimax13x@gmail.com', '$2y$10$PqGU9yppHO/xMK4RuvmeJesORLTbNSrlXlwqQocEngjX3i1r82zvq', 'seller'),
(7, 'reza', 'reza23@gmail.com', '$2y$10$nJ8y2MCY0AigkqaLRUEERe2ywOS8JzfDISPDplWF.JBmyNm4aHkq6', 'buyer'),
(8, 'mahyar', 'mahyar@gmail.com', '$2y$10$rR7F0ny4IB/UO467a0lfaO1Bk9P1rCa35POkP1hzRcN4fMfTpD3DK', 'buyer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
