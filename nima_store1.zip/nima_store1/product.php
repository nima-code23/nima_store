<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
// گرفتن نرخ دلار
$rate = 0;
$response = @file_get_contents("https://open.er-api.com/v6/latest/USD");
if ($response) {
    $data = json_decode($response, true);
    if (isset($data['rates']['IRR'])) {
        $rate = intval($data['rates']['IRR']);
    }
}

// گرفتن اطلاعات محصول
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<div class='alert alert-danger m-4'>محصولی یافت نشد.</div>";
    exit;
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<div class='alert alert-warning m-4'>محصولی با این مشخصات پیدا نشد.</div>";
    exit;
}

$product = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($product['name']) ?> | Nima Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/nima_store1/assets/style.css">
    <style>
        .dollar-box {
            position: fixed;
            top: 10px;
            left: 10px;
            background: #f0f0f0;
            padding: 10px 15px;
            border-radius: 8px;
            font-weight: bold;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
            z-index: 1000;
        }
        .toast-message {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #198754;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.3s ease, transform 0.3s ease;
            font-weight: bold;
            z-index: 10000;
            pointer-events: none;
        }
        .toast-message.show {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>
<body>

<?php if ($rate > 0): ?>
    <div class="dollar-box">
        💵 نرخ دلار: <strong><?= number_format($rate) ?> ریال</strong>
    </div>
<?php endif; ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">
            <img src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="img-fluid rounded shadow-sm">
        </div>
        <div class="col-md-6">
            <h2><?= htmlspecialchars($product['name']) ?></h2>
            <p class="text-muted"><?= nl2br(htmlspecialchars($product['description'])) ?></p>

            <p><strong>قیمت:</strong> $<?= floatval($product['price_dollar']) ?></p>
            <?php if ($rate > 0): ?>
                <p class="text-success"><strong>معادل ریالی:</strong> <?= number_format(floatval($product['price_dollar']) * $rate) ?> ریال</p>
            <?php endif; ?>

            <form method="post" action="/nima_store1/add_to_cart.php" class="add-to-cart-form mt-3" data-product-name="<?= htmlspecialchars($product['name']) ?>">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <input type="hidden" name="name" value="<?= htmlspecialchars($product['name']) ?>">
                <input type="hidden" name="price" value="<?= floatval($product['price_dollar']) ?>">
                <button type="submit" class="btn btn-success w-100">افزودن به سبد خرید</button>
            </form>

            <a href="/nima_store1/products.php" class="btn btn-link mt-3 d-block text-decoration-none">⬅ بازگشت به فروشگاه</a>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.add-to-cart-form').forEach(form => {
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(this);

        fetch(this.action, {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            showToast(`✅ محصول "${this.dataset.productName}" به سبد خرید اضافه شد.`);
        })
        .catch(err => {
            showToast("❌ خطا در افزودن به سبد خرید.");
        });
    });
});

function showToast(message) {
    let toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => toast.classList.add('show'), 100);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
</script>

</body>
</html>