<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'seller') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $id = intval($_POST['product_id']);
    
    // حذف تصویر از پوشه uploads
    $res = $conn->query("SELECT image FROM products WHERE id = $id");
    if ($res && $res->num_rows > 0) {
        $img = $res->fetch_assoc()['image'];
        if (file_exists("uploads/$img")) {
            unlink("uploads/$img");
        }
    }

    // حذف از دیتابیس
    $conn->query("DELETE FROM products WHERE id = $id");
}

header("Location: products.php");
exit;