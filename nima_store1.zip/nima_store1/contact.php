<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';
require_once 'includes/mailer.php'; // برای ارسال ایمیل با PHPMailer

$success = false;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name === '' || $email === '' || $subject === '' || $message === '') {
        $errors[] = "لطفاً تمام فیلدها را پر کنید.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "آدرس ایمیل معتبر نیست.";
    } else {
        // ذخیره در دیتابیس
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $subject, $message);
        $stmt->execute();

        // ارسال ایمیل به مدیر سایت
        $to = "nimax13x@gmail.com";  // 🔁 اینو با ایمیل واقعی مدیر جایگزین کن
        $emailSent = sendEmail($to, "[تماس با ما] $subject", $message, $name, $email);

        if ($emailSent) {
            $success = true;
        } else {
            $errors[] = "ارسال ایمیل با خطا مواجه شد. لطفاً دوباره تلاش کنید.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
  <meta charset="UTF-8">
  <title>تماس با ما | Nima Store</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-body">
          <h3 class="text-center mb-4">📬 تماس با ما</h3>

          <?php if ($success): ?>
              <div class="alert alert-success text-center fw-bold">
                ✅ پیام شما با موفقیت ارسال شد!
              </div>
          <?php elseif ($errors): ?>
              <div class="alert alert-danger">
                <ul class="mb-0">
                  <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                  <?php endforeach; ?>
                </ul>
              </div>
          <?php endif; ?>

          <form method="post" action="">
            <div class="mb-3">
              <label class="form-label">نام:</label>
              <input type="text" name="name" class="form-control" required>
            </div>

            <div class="mb-3">
              <label class="form-label">ایمیل:</label>
              <input type="email" name="email" class="form-control" required>
            </div>

            <div class="mb-3">
              <label class="form-label">موضوع:</label>
              <input type="text" name="subject" class="form-control" required>
            </div>

            <div class="mb-3">
              <label class="form-label">پیام:</label>
              <textarea name="message" class="form-control" rows="5" required></textarea>
            </div>

            <button type="submit" class="btn btn-primary w-100">ارسال پیام</button>
          </form>

        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>